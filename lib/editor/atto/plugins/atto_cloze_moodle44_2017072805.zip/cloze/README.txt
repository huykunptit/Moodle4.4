atto_cloze
=================

This is an editor plugin to provide an interface for creating and
modifying embedded answer (cloze) questions. To install add to the Atto
editor plugins directory and visit notifications to update database. This
directory must be named 'cloze' in lib/editor/atto/plugins. Then
add 'cloze' to the list of buttons in Atto toolbar settings at Site
administration -> Plugins -> Text editors -> Atto HTML editor -> Atto
toolbar settings.

The button should appear in the editor only while editing questions. Click
the button while editing a question, select the question type and a form
will appear form entering answers. Finally insert into the question text.

All original files are copyright Daniel Thies 2016 dethies@gmail.com and
are licensed under the included GPL 3

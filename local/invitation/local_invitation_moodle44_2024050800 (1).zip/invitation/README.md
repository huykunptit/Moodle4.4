# Local plugin: Invitation

With this plugin you can invite users, who do not have an account, to your course.

## Installation
* Unzip and copy the plugin into the folder "local/invitation.
* Visit admin page to install the plugin.

Further installation instructions can be found on the
"[Installing plugins](http://docs.moodle.org/en/Installing_contributed_modules_or_plugins)" Moodle documentation page.
